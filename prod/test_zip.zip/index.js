
process.env.LD_LIBRARY_PATH = './bin';

const child = require('child_process');
const fs = require('fs');

console.log('Loading function');

var x = 1;

exports.handler = (event, context, callback) => {
  
  var out = '';
  x++;
  context.callbackWaitsForEmptyEventLoop = false;

  //if (process.env.CLEAR_TMP) {
  //  console.log('attempting to clear /tmp directory')
    console.log(child.execSync('rm -rf /tmp/core*').toString());
   // child.execSync('chmod 777 ./bin/*');
  //}

  //if (process.env.DEBUG_ENV) {
    //log(child.execSync('set').toString());
   // console.log(child.execSync('pwd').toString());
   // console.log(child.execSync('ls -lhtra .').toString());
   // console.log(child.execSync('ls -lhtra /tmp').toString());
  //}

  console.log('Received event:', JSON.stringify(event, null, 2));
  
  var protractor_cp = child.spawn('node',['node_modules/protractor/bin/protractor','conf.js']);
  
  protractor_cp.stderr.on('data',function(data){
	  out += data.toString('utf8');	  
  });
  
  protractor_cp.stdout.on('data',function(data){
	  out += data.toString('utf8');	  
  });
  
  protractor_cp.on('exit',function(code){
	  console.log('exit code ',code);
	  setTimeout(function(){
        console.log('finished....');
		var minfo = process.memoryUsage();
		var used = minfo.rss/1024/1024;
        callback(null, 
           {
                statusCode: '200',
                body: out+' ---------------------- done tested count '+x+' with code '+code+', mem used: '+used,
                headers: {
                    'Content-Type': 'text/plain',
                }
            }
        );
    },2000);
  });
  
};
