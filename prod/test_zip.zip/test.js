
process.env.LD_LIBRARY_PATH = './bin';

const child = require('child_process');
const fs = require('fs');

  var protractor_cp = child.spawn('node',['node_modules/protractor/bin/protractor','conf.js']);
  
  protractor_cp.stderr.on('data',function(data){
	  console.log(data.toString('utf8'));
  });
  
  protractor_cp.stdout.on('data',function(data){
	  console.log(data.toString('utf8'));
  });
  
  protractor_cp.on('exit',function(code){
	  console.log('exit code ',code);
	  
  });
  